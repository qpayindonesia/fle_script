<center>
		<footer>
		<p>Technology Resource Inventory System (T.R.I.S) Copyright 2015</p>	
		</footer>
</center>

