      
**/

User guide

1. install wamp server.
2. upload source file to WWW wamp directory.
3. create database name thesis
4. import database
5. run localhost link to the source code.
6. administrator;
   Username:admin 
   password:admin
   hope that it will be useful: Enjoy
