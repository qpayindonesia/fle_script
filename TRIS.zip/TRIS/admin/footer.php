<div class="pull-right">
		<footer align="center">
           <p>All Right Reserved T.R.I.S Powered by Code Warrior 2015</p>
        <footer>
</div>